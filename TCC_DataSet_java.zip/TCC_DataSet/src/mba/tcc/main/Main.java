package mba.tcc.main;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import mba.tcc.main.pojo.Root;
import mba.tcc.main.pojo.Value;

public class Main {

	public static void main(String[] args) throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();

		try (Stream<Path> walkStream = Files.walk(Paths.get("C:\\Users\\dayse\\OneDrive\\Documentos\\backup_dell\\mba_usp\\TCC\\polichinelo_videos\\video_008_eu_rosca_30_rep\\"))) {
		//try (Stream<Path> walkStream = Files.walk(Paths.get("C:\\Users\\dayse\\OneDrive\\Documentos\\backup_dell\\mba_usp\\TCC\\abdominal_videos\\"))) {
		    walkStream.filter(p -> p.toFile().isFile()).forEach(f -> {
		        if (f.toString().endsWith(".txt")) {
		        	List<Root> books = null;
					try {
						books = Arrays.asList(objectMapper.readValue(f.toFile(), Root[].class));
					} catch (JsonParseException e) {
						e.printStackTrace();
					} catch (JsonMappingException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
		    		StringBuilder sb = new StringBuilder();
		    		sb.append("EXERCICIO").append(",").append("FILENAME").append(",").append("SEQ")
		    		.append(",").append("NOSE_X").append(",").append("NOSE_Y").append(",").append("NOSE_SCORE")
		    		.append(",").append("LEFT_EYE_X").append(",").append("LEFT_EYE_Y").append(",").append("LEFT_EYE_SCORE")
		    		.append(",").append("RIGHT_EYE_X").append(",").append("RIGHT_EYE_Y").append(",").append("RIGHT_EYE_SCORE")
		    		.append(",").append("LEFT_EAR_X").append(",").append("LEFT_EAR_Y").append(",").append("LEFT_EAR_SCORE")
		    		.append(",").append("RIGHT_EAR_X").append(",").append("RIGHT_EAR_Y").append(",").append("RIGHT_EAR_SCORE")
		    		.append(",").append("LEFT_SHOULDER_X").append(",").append("LEFT_SHOULDER_Y").append(",").append("LEFT_SHOULDER_SCORE")
		    		.append(",").append("RIGHT_SHOULDER_X").append(",").append("RIGHT_SHOULDER_Y").append(",").append("RIGHT_SHOULDER_SCORE")
		    		.append(",").append("LEFT_ELBOW_X").append(",").append("LEFT_ELBOW_Y").append(",").append("LEFT_ELBOW_SCORE")
		    		.append(",").append("RIGHT_ELBOW_X").append(",").append("RIGHT_ELBOW_Y").append(",").append("RIGHT_ELBOW_SCORE")
		    		.append(",").append("LEFT_WRIST_X").append(",").append("LEFT_WRIST_Y").append(",").append("LEFT_WRIST_SCORE")
		    		.append(",").append("RIGHT_WRIST_X").append(",").append("RIGHT_WRIST_Y").append(",").append("RIGHT_WRIST_SCORE")
		    		.append(",").append("LEFT_HIP_X").append(",").append("LEFT_HIP_Y").append(",").append("LEFT_HIP_SCORE")
		    		.append(",").append("RIGHT_HIP_X").append(",").append("RIGHT_HIP_Y").append(",").append("RIGHT_HIP_SCORE")
		    		.append(",").append("LEFT_KNEE_X").append(",").append("LEFT_KNEE_Y").append(",").append("LEFT_KNEE_SCORE")
		    		.append(",").append("RIGHT_KNEE_X").append(",").append("RIGHT_KNEE_Y").append(",").append("RIGHT_KNEE_SCORE")
		    		.append(",").append("LEFT_ANKLE_X").append(",").append("LEFT_ANKLE_Y").append(",").append("LEFT_ANKLE_SCORE")
		    		.append(",").append("RIGHT_ANKLE_X").append(",").append("RIGHT_ANKLE_Y").append(",").append("RIGHT_ANKLE_SCORE\n");
		    		
		    		for (Root root : books) {
		    			//TODO: TROCAR O C�DIGO: 0 - POLICHINELO; 1 - ABDOMINAL
		    			sb.append("0").append(",").append(root.key.substring(0, root.key.lastIndexOf("_"))).append(",").append(root.key.substring(root.key.lastIndexOf("_") + 1)).append(",");
		    			for (Value value : root.value) {
		    				if("nose".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("left_eye".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("right_eye".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("left_ear".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("right_ear".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("left_shoulder".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("right_shoulder".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("left_elbow".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("right_elbow".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("left_wrist".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("right_wrist".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("left_hip".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("right_hip".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("left_knee".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("right_knee".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("left_ankle".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append(",");
		    				}
		    				if("right_ankle".equals(value.name)) {
		    					sb.append(value.x).append(",").append(value.y).append(",").append(value.score).append("\n");
		    				}
		    			}
		    		}
		    		try {
						FileUtils.writeStringToFile(new File(f.getParent() + "\\" + f.getFileName() + ".csv"), sb.toString(), Charset.forName("UTF-8"));
					} catch (IOException e) {
						e.printStackTrace();
					}
		        }
		    });
		}
		
		
	}

}
