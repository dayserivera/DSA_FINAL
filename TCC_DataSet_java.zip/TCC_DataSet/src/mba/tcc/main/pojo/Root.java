package mba.tcc.main.pojo;

import java.util.ArrayList;

public class Root {
	public String key;
    public ArrayList<Value> value;
    
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public ArrayList<Value> getValue() {
		return value;
	}
	public void setValue(ArrayList<Value> value) {
		this.value = value;
	}
    
}
