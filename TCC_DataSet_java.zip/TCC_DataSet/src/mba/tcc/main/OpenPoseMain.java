package mba.tcc.main;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.io.FileUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OpenPoseMain {

	public static void main(String[] args) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		StringBuilder sb = new StringBuilder();
		
		sb.append("NOSE_X").append(",").append("NOSE_Y").append(",").append("NOSE_SCORE").append(",")
		.append("NECK_X").append(",").append("NECK_Y").append(",").append("NECK_SCORE").append(",")
		.append("RIGHT_SHOULDER_X").append(",").append("RIGHT_SHOULDER_Y").append(",").append("RIGHT_SHOULDER_SCORE")
		.append(",").append("RIGHT_ELBOW_X").append(",").append("RIGHT_ELBOW_Y").append(",").append("RIGHT_ELBOW_SCORE").append(",")
		.append("RIGHT_WRIST_X").append(",").append("RIGHT_WRIST_Y").append(",").append("RIGHT_WRIST_SCORE")
		.append(",").append("LEFT_SHOULDER_X").append(",").append("LEFT_SHOULDER_Y").append(",").append("LEFT_SHOULDER_SCORE").append(",")
		.append("LEFT_ELBOW_X").append(",").append("LEFT_ELBOW_Y").append(",").append("LEFT_ELBOW_SCORE")
		.append(",").append("LEFT_WRIST_X").append(",").append("LEFT_WRIST_Y").append(",").append("LEFT_WRIST_SCORE").append(",")
		.append("RIGHT_HIP_X").append(",").append("RIGHT_HIP_Y").append(",").append("RIGHT_HIP_SCORE")
		.append(",").append("RIGHT_KNEE_X").append(",").append("RIGHT_KNEE_Y").append(",").append("RIGHT_KNEE_SCORE").append(",")
		.append("RIGHT_ANKLE_X").append(",").append("RIGHT_ANKLE_Y").append(",").append("RIGHT_ANKLE_SCORE").append(",")
		.append("LEFT_HIP_X").append(",").append("LEFT_HIP_Y").append(",").append("LEFT_HIP_SCORE").append(",")
		.append("LEFT_KNEE_X").append(",").append("LEFT_KNEE_Y").append(",").append("LEFT_KNEE_SCORE").append(",")
		.append("LEFT_ANKLE_X").append(",").append("LEFT_ANKLE_Y").append(",").append("LEFT_ANKLE_SCORE")
		.append(",").append("RIGHT_EYE_X").append(",").append("RIGHT_EYE_Y").append(",").append("RIGHT_EYE_SCORE").append(",")
		.append("LEFT_EYE_X").append(",").append("LEFT_EYE_Y").append(",").append("LEFT_EYE_SCORE").append(",")
		.append("RIGHT_EAR_X").append(",").append("RIGHT_EAR_Y").append(",").append("RIGHT_EAR_SCORE").append(",").
		append("LEFT_EAR_X").append(",").append("LEFT_EAR_Y").append(",").append("LEFT_EAR_SCORE\n");
		
		String dir = "TCC\\exercicios_final\\roscaDireta\\openPoseKeypoints_roscaDireta_25\\";
		try (Stream<Path> walkStream = Files.walk(Paths.get(
				dir))) {
			walkStream.sorted((o1, o2) -> o1.getFileName().compareTo(o2.getFileName())).filter(p -> p.toFile().isFile()).forEach(f -> {
				if (f.toString().endsWith(".json")) {
					System.out.println(f);
					List<OpenPose> poses = null;
					try {
						poses = Arrays.asList(objectMapper.readValue(f.toFile(), OpenPose.class));
					} catch (JsonParseException e) {
						e.printStackTrace();
					} catch (JsonMappingException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}

					for (OpenPose root : poses) {
						List<Double> poseKeypoints2d = root.getPeople().get(0).getPose_keypoints_2d();
						int i = 0;
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append(",");
						sb.append(poseKeypoints2d.get(i++)).append(",").append(poseKeypoints2d.get(i++)).append(",")
								.append(poseKeypoints2d.get(i++)).append("\n");
					}
				}
			});
		}
		try {
			FileUtils.writeStringToFile(new File(dir + "\\openPoseKeypoints.csv"), sb.toString(),
					Charset.forName("UTF-8"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
