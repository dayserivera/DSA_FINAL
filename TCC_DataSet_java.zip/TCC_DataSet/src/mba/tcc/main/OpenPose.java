package mba.tcc.main;

import java.util.ArrayList;

public class OpenPose {
	private float version;
	ArrayList<Person> people = new ArrayList<Person>();

	// Getter Methods

	public float getVersion() {
		return version;
	}

	// Setter Methods

	public void setVersion(float version) {
		this.version = version;
	}

	public ArrayList<Person> getPeople() {
		return people;
	}

	public void setPeople(ArrayList<Person> people) {
		this.people = people;
	}
	
}

class Person {
	ArrayList < Object > person_id = new ArrayList < Object > ();
	ArrayList < Double > pose_keypoints_2d = new ArrayList < Double > ();
	ArrayList < Object > face_keypoints_2d = new ArrayList < Object > ();
	ArrayList < Object > hand_left_keypoints_2d = new ArrayList < Object > ();
	ArrayList < Object > hand_right_keypoints_2d = new ArrayList < Object > ();
	ArrayList < Object > pose_keypoints_3d = new ArrayList < Object > ();
	ArrayList < Object > face_keypoints_3d = new ArrayList < Object > ();
	ArrayList < Object > hand_left_keypoints_3d = new ArrayList < Object > ();
	ArrayList < Object > hand_right_keypoints_3d = new ArrayList < Object > ();
	public ArrayList<Object> getPerson_id() {
		return person_id;
	}
	public void setPerson_id(ArrayList<Object> person_id) {
		this.person_id = person_id;
	}
	public ArrayList<Double> getPose_keypoints_2d() {
		return pose_keypoints_2d;
	}
	public void setPose_keypoints_2d(ArrayList<Double> pose_keypoints_2d) {
		this.pose_keypoints_2d = pose_keypoints_2d;
	}
	public ArrayList<Object> getFace_keypoints_2d() {
		return face_keypoints_2d;
	}
	public void setFace_keypoints_2d(ArrayList<Object> face_keypoints_2d) {
		this.face_keypoints_2d = face_keypoints_2d;
	}
	public ArrayList<Object> getHand_left_keypoints_2d() {
		return hand_left_keypoints_2d;
	}
	public void setHand_left_keypoints_2d(ArrayList<Object> hand_left_keypoints_2d) {
		this.hand_left_keypoints_2d = hand_left_keypoints_2d;
	}
	public ArrayList<Object> getHand_right_keypoints_2d() {
		return hand_right_keypoints_2d;
	}
	public void setHand_right_keypoints_2d(ArrayList<Object> hand_right_keypoints_2d) {
		this.hand_right_keypoints_2d = hand_right_keypoints_2d;
	}
	public ArrayList<Object> getPose_keypoints_3d() {
		return pose_keypoints_3d;
	}
	public void setPose_keypoints_3d(ArrayList<Object> pose_keypoints_3d) {
		this.pose_keypoints_3d = pose_keypoints_3d;
	}
	public ArrayList<Object> getFace_keypoints_3d() {
		return face_keypoints_3d;
	}
	public void setFace_keypoints_3d(ArrayList<Object> face_keypoints_3d) {
		this.face_keypoints_3d = face_keypoints_3d;
	}
	public ArrayList<Object> getHand_left_keypoints_3d() {
		return hand_left_keypoints_3d;
	}
	public void setHand_left_keypoints_3d(ArrayList<Object> hand_left_keypoints_3d) {
		this.hand_left_keypoints_3d = hand_left_keypoints_3d;
	}
	public ArrayList<Object> getHand_right_keypoints_3d() {
		return hand_right_keypoints_3d;
	}
	public void setHand_right_keypoints_3d(ArrayList<Object> hand_right_keypoints_3d) {
		this.hand_right_keypoints_3d = hand_right_keypoints_3d;
	}
	
}